from __future__ import annotations

import os
import secrets
import sqlite3
import uuid
from datetime import datetime, timedelta, timezone
from functools import wraps
from pathlib import Path

from flask import Flask, g, jsonify, request, session
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DATABASE_PATH = Path(os.environ.get("BANK_DB_PATH", BASE_DIR / "banking.db"))
UNDO_SECONDS = 30

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("BANK_SECRET_KEY", secrets.token_hex(32))
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("COOKIE_SECURE", "0") == "1"
app.json.sort_keys = False


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime | None = None) -> str:
    return (dt or utc_now()).isoformat(timespec="milliseconds")


def parse_time(value: str) -> datetime:
    return datetime.fromisoformat(value)


def to_paise(value) -> int:
    """Convert a rupee amount supplied as a string/number to integer paise."""
    from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
    try:
        amount = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError("Amount must be a valid number.")
    if not amount.is_finite() or amount <= 0:
        raise ValueError("Amount must be greater than zero.")
    paise = (amount * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    if amount != (paise / Decimal(100)):
        raise ValueError("Amount can have at most two decimal places.")
    result = int(paise)
    if result <= 0:
        raise ValueError("Amount must be at least ₹0.01.")
    return result


def rupees(paise: int) -> str:
    return f"{paise / 100:.2f}"


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        conn = sqlite3.connect(DATABASE_PATH, timeout=10, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA busy_timeout = 10000")
        g.db = conn
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DATABASE_PATH)
    try:
        conn.execute("PRAGMA foreign_keys = ON")
        schema = (BASE_DIR / "schema.sql").read_text(encoding="utf-8")
        conn.executescript(schema)
        conn.commit()
    finally:
        conn.close()


def audit(actor_id, action, entity_id=None, details=None):
    get_db().execute(
        "INSERT INTO audit_logs(actor_account_id, action, entity_id, details, created_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (actor_id, action, entity_id, details, iso()),
    )


def account_public(row):
    available = row["balance_paise"] - row["reserved_paise"]
    return {
        "account_id": row["account_id"],
        "account_number": row["account_number"],
        "full_name": row["full_name"],
        "username": row["username"],
        "status": row["status"],
        "balance": rupees(row["balance_paise"]),
        "reserved": rupees(row["reserved_paise"]),
        "available_balance": rupees(available),
        "created_at": row["created_at"],
    }


def transaction_public(row, current_id=None):
    return {
        "transaction_id": row["transaction_id"],
        "sender_account_id": row["sender_account_id"],
        "receiver_account_id": row["receiver_account_id"],
        "amount": rupees(row["amount_paise"]),
        "status": row["status"],
        "created_at": row["created_at"],
        "expires_at": row["expires_at"],
        "finalized_at": row["finalized_at"],
        "cancelled_at": row["cancelled_at"],
        "can_cancel": (
            row["status"] == "PENDING"
            and current_id == row["sender_account_id"]
            and utc_now() < parse_time(row["expires_at"])
        ),
    }


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "account_id" not in session:
            return jsonify(error="Login required."), 401
        return fn(*args, **kwargs)
    return wrapper


def finalize_transaction(transaction_id: str) -> bool:
    """Finalize an expired pending transfer exactly once, atomically."""
    db = get_db()
    now = utc_now()
    db.execute("BEGIN IMMEDIATE")
    try:
        tx = db.execute(
            "SELECT * FROM transactions WHERE transaction_id = ?", (transaction_id,)
        ).fetchone()
        if not tx or tx["status"] != "PENDING" or parse_time(tx["expires_at"]) > now:
            db.execute("ROLLBACK")
            return False

        changed = db.execute(
            "UPDATE transactions SET status='COMPLETED', finalized_at=? "
            "WHERE transaction_id=? AND status='PENDING' AND expires_at<=?",
            (iso(now), transaction_id, iso(now)),
        ).rowcount
        if changed != 1:
            db.execute("ROLLBACK")
            return False

        amount = tx["amount_paise"]
        sender = db.execute(
            "SELECT * FROM accounts WHERE account_id=?", (tx["sender_account_id"],)
        ).fetchone()
        receiver = db.execute(
            "SELECT * FROM accounts WHERE account_id=?", (tx["receiver_account_id"],)
        ).fetchone()

        if not sender or not receiver or sender["reserved_paise"] < amount:
            raise RuntimeError("Account or reservation integrity check failed.")
        if sender["balance_paise"] < amount:
            raise RuntimeError("Sender balance integrity check failed.")

        db.execute(
            "UPDATE accounts SET balance_paise=balance_paise-?, "
            "reserved_paise=reserved_paise-? WHERE account_id=?",
            (amount, amount, tx["sender_account_id"]),
        )
        db.execute(
            "UPDATE accounts SET balance_paise=balance_paise+? WHERE account_id=?",
            (amount, tx["receiver_account_id"]),
        )
        timestamp = iso(now)
        db.execute(
            "INSERT INTO ledger_entries(transaction_id, account_id, entry_type, amount_paise, created_at) "
            "VALUES (?, ?, 'DEBIT', ?, ?)",
            (transaction_id, tx["sender_account_id"], amount, timestamp),
        )
        db.execute(
            "INSERT INTO ledger_entries(transaction_id, account_id, entry_type, amount_paise, created_at) "
            "VALUES (?, ?, 'CREDIT', ?, ?)",
            (transaction_id, tx["receiver_account_id"], amount, timestamp),
        )
        audit(tx["sender_account_id"], "TRANSFER_COMPLETED", transaction_id, "Expired undo window")
        db.execute("COMMIT")
        return True
    except Exception:
        db.execute("ROLLBACK")
        raise


def process_expired_for_account(account_id: int):
    """On-demand expiry processing, so pending transfers still complete after a restart."""
    db = get_db()
    expired = db.execute(
        "SELECT transaction_id FROM transactions WHERE status='PENDING' AND expires_at<=? "
        "AND (sender_account_id=? OR receiver_account_id=?) ORDER BY expires_at",
        (iso(), account_id, account_id),
    ).fetchall()
    for row in expired:
        try:
            finalize_transaction(row["transaction_id"])
        except (RuntimeError, sqlite3.Error):
            app.logger.exception("Could not finalize transaction %s", row["transaction_id"])


@app.get("/")
def index():
    return jsonify(
        name="Secure Banking Management System API",
        mode="academic prototype",
        undo_window_seconds=UNDO_SECONDS,
        endpoints={
            "POST /api/register": "Create an account",
            "POST /api/login": "Log in",
            "POST /api/logout": "Log out",
            "GET /api/me": "View current account",
            "POST /api/transfers": "Create a pending transfer",
            "GET /api/transactions": "View transactions",
            "POST /api/transfers/<id>/cancel": "Cancel a pending transfer within 30 seconds",
            "GET /api/health": "Health check",
        },
    )


@app.get("/api/health")
def health():
    return jsonify(status="ok", database="SQLite", prototype=True)


@app.post("/api/register")
def register():
    data = request.get_json(silent=True) or {}
    full_name = str(data.get("full_name", "")).strip()
    username = str(data.get("username", "")).strip().lower()
    password = data.get("password", "")
    if not full_name or len(full_name) > 100:
        return jsonify(error="Full name is required (maximum 100 characters)."), 400
    if not username or len(username) < 3 or len(username) > 40:
        return jsonify(error="Username must be 3–40 characters."), 400
    if not isinstance(password, str) or len(password) < 8:
        return jsonify(error="Password must contain at least 8 characters."), 400

    db = get_db()
    account_number = str(1000000000 + secrets.randbelow(9000000000))
    try:
        db.execute("BEGIN IMMEDIATE")
        cur = db.execute(
            "INSERT INTO accounts(account_number, full_name, username, password_hash, "
            "balance_paise, reserved_paise, status, created_at) VALUES (?, ?, ?, ?, 0, 0, 'ACTIVE', ?)",
            (account_number, full_name, username, generate_password_hash(password), iso()),
        )
        account_id = cur.lastrowid
        audit(account_id, "ACCOUNT_CREATED", str(account_id))
        db.execute("COMMIT")
    except sqlite3.IntegrityError:
        db.execute("ROLLBACK")
        return jsonify(error="That username is already registered."), 409
    except Exception:
        db.execute("ROLLBACK")
        raise
    session.clear()
    session["account_id"] = account_id
    row = db.execute("SELECT * FROM accounts WHERE account_id=?", (account_id,)).fetchone()
    return jsonify(message="Account created.", account=account_public(row)), 201


@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip().lower()
    password = data.get("password", "")
    row = get_db().execute("SELECT * FROM accounts WHERE username=?", (username,)).fetchone()
    if not row or not isinstance(password, str) or not check_password_hash(row["password_hash"], password):
        audit(row["account_id"] if row else None, "LOGIN_FAILURE", None, "Invalid credentials")
        return jsonify(error="Invalid username or password."), 401
    if row["status"] != "ACTIVE":
        return jsonify(error="This account is frozen."), 403
    session.clear()
    session["account_id"] = row["account_id"]
    audit(row["account_id"], "LOGIN_SUCCESS")
    return jsonify(message="Login successful.", account=account_public(row))


@app.post("/api/logout")
@login_required
def logout():
    session.clear()
    return jsonify(message="Logged out.")


@app.get("/api/me")
@login_required
def me():
    account_id = session["account_id"]
    process_expired_for_account(account_id)
    row = get_db().execute("SELECT * FROM accounts WHERE account_id=?", (account_id,)).fetchone()
    return jsonify(account=account_public(row))


@app.post("/api/transfers")
@login_required
def create_transfer():
    data = request.get_json(silent=True) or {}
    try:
        receiver_account_number = str(data.get("receiver_account_number", "")).strip()
        amount = to_paise(data.get("amount"))
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    if not receiver_account_number:
        return jsonify(error="receiver_account_number is required."), 400

    db = get_db()
    sender_id = session["account_id"]
    process_expired_for_account(sender_id)
    db.execute("BEGIN IMMEDIATE")
    try:
        sender = db.execute("SELECT * FROM accounts WHERE account_id=?", (sender_id,)).fetchone()
        receiver = db.execute(
            "SELECT * FROM accounts WHERE account_number=?", (receiver_account_number,)
        ).fetchone()
        if not sender or sender["status"] != "ACTIVE":
            db.execute("ROLLBACK")
            return jsonify(error="Sender account is unavailable."), 403
        if not receiver or receiver["status"] != "ACTIVE":
            db.execute("ROLLBACK")
            return jsonify(error="Recipient account not found or inactive."), 404
        if sender["account_id"] == receiver["account_id"]:
            db.execute("ROLLBACK")
            return jsonify(error="You cannot transfer to your own account."), 400
        available = sender["balance_paise"] - sender["reserved_paise"]
        if available < amount:
            db.execute("ROLLBACK")
            return jsonify(error="Insufficient available balance."), 400

        now = utc_now()
        txid = str(uuid.uuid4())
        expiry = now + timedelta(seconds=UNDO_SECONDS)
        db.execute(
            "UPDATE accounts SET reserved_paise=reserved_paise+? WHERE account_id=?",
            (amount, sender_id),
        )
        db.execute(
            "INSERT INTO transactions(transaction_id, sender_account_id, receiver_account_id, "
            "amount_paise, status, created_at, expires_at) VALUES (?, ?, ?, ?, 'PENDING', ?, ?)",
            (txid, sender_id, receiver["account_id"], amount, iso(now), iso(expiry)),
        )
        audit(sender_id, "TRANSFER_REQUESTED", txid, f"Amount paise={amount}")
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK")
        raise

    tx = db.execute("SELECT * FROM transactions WHERE transaction_id=?", (txid,)).fetchone()
    return jsonify(
        message="Transfer is pending. You can cancel it before the 30-second window expires.",
        transaction=transaction_public(tx, sender_id),
    ), 201


@app.get("/api/transactions")
@login_required
def transactions():
    account_id = session["account_id"]
    process_expired_for_account(account_id)
    rows = get_db().execute(
        "SELECT * FROM transactions WHERE sender_account_id=? OR receiver_account_id=? "
        "ORDER BY created_at DESC LIMIT 100",
        (account_id, account_id),
    ).fetchall()
    return jsonify(transactions=[transaction_public(row, account_id) for row in rows])


@app.post("/api/transfers/<transaction_id>/cancel")
@login_required
def cancel_transfer(transaction_id):
    db = get_db()
    account_id = session["account_id"]
    now = utc_now()
    db.execute("BEGIN IMMEDIATE")
    try:
        tx = db.execute(
            "SELECT * FROM transactions WHERE transaction_id=?", (transaction_id,)
        ).fetchone()
        if not tx:
            db.execute("ROLLBACK")
            return jsonify(error="Transaction not found."), 404
        if tx["sender_account_id"] != account_id:
            db.execute("ROLLBACK")
            return jsonify(error="Only the sender can cancel this transfer."), 403
        if tx["status"] != "PENDING":
            db.execute("ROLLBACK")
            return jsonify(error=f"Transfer is already {tx['status']}."), 409
        if now >= parse_time(tx["expires_at"]):
            db.execute("ROLLBACK")
            try:
                finalize_transaction(transaction_id)
            except (RuntimeError, sqlite3.Error):
                app.logger.exception("Expiry finalization failed for %s", transaction_id)
            return jsonify(error="The 30-second undo window has expired; cancellation is no longer available."), 409

        changed = db.execute(
            "UPDATE transactions SET status='CANCELLED', cancelled_at=? "
            "WHERE transaction_id=? AND status='PENDING' AND expires_at>?",
            (iso(now), transaction_id, iso(now)),
        ).rowcount
        if changed != 1:
            db.execute("ROLLBACK")
            return jsonify(error="Transfer status changed; refresh transaction history."), 409
        amount = tx["amount_paise"]
        db.execute(
            "UPDATE accounts SET reserved_paise=reserved_paise-? "
            "WHERE account_id=? AND reserved_paise>=?",
            (amount, account_id, amount),
        )
        audit(account_id, "TRANSFER_CANCELLED", transaction_id)
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK")
        raise
    return jsonify(message="Transfer cancelled and reserved funds released.", transaction_id=transaction_id, status="CANCELLED")


@app.get("/api/integrity-check")
@login_required
def integrity_check():
    # Prototype diagnostic endpoint: users can inspect consistency only for their own records.
    account_id = session["account_id"]
    db = get_db()
    row = db.execute(
        "SELECT account_id, balance_paise, reserved_paise, status FROM accounts WHERE account_id=?",
        (account_id,),
    ).fetchone()
    issues = []
    if row["reserved_paise"] > row["balance_paise"]:
        issues.append("Reserved funds exceed posted balance.")
    pending = db.execute(
        "SELECT transaction_id, amount_paise FROM transactions WHERE sender_account_id=? AND status='PENDING'",
        (account_id,),
    ).fetchall()
    expected_reserved = sum(x["amount_paise"] for x in pending)
    if expected_reserved != row["reserved_paise"]:
        issues.append("Reserved balance does not match pending outgoing transfers.")
    ledger_rows = db.execute(
        "SELECT t.transaction_id, t.amount_paise, "
        "SUM(CASE WHEN l.entry_type='DEBIT' THEN l.amount_paise ELSE 0 END) AS debits, "
        "SUM(CASE WHEN l.entry_type='CREDIT' THEN l.amount_paise ELSE 0 END) AS credits, "
        "COUNT(l.entry_id) AS n "
        "FROM transactions t LEFT JOIN ledger_entries l ON l.transaction_id=t.transaction_id "
        "WHERE (t.sender_account_id=? OR t.receiver_account_id=?) AND t.status='COMPLETED' "
        "GROUP BY t.transaction_id",
        (account_id, account_id),
    ).fetchall()
    for tx in ledger_rows:
        if tx["n"] != 2 or tx["debits"] != tx["amount_paise"] or tx["credits"] != tx["amount_paise"]:
            issues.append(f"Ledger mismatch for transaction {tx['transaction_id']}.")
    return jsonify(ok=not issues, issues=issues, checked_account_id=account_id)


@app.errorhandler(500)
def internal_error(_error):
    return jsonify(error="An internal error occurred. Check the application log for details."), 500


if __name__ == "__main__":
    init_db()
    print(f"Database: {DATABASE_PATH}")
    print("Running academic prototype at http://127.0.0.1:5000")
    app.run(debug=os.environ.get("FLASK_DEBUG", "0") == "1")
