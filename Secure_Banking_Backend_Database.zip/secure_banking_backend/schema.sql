PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS accounts (
    account_id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_number TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    balance_paise INTEGER NOT NULL DEFAULT 0 CHECK (balance_paise >= 0),
    reserved_paise INTEGER NOT NULL DEFAULT 0 CHECK (reserved_paise >= 0),
    status TEXT NOT NULL DEFAULT 'ACTIVE'
        CHECK (status IN ('ACTIVE', 'FROZEN')),
    created_at TEXT NOT NULL,
    CHECK (reserved_paise <= balance_paise)
);

CREATE TABLE IF NOT EXISTS transactions (
    transaction_id TEXT PRIMARY KEY,
    sender_account_id INTEGER NOT NULL REFERENCES accounts(account_id),
    receiver_account_id INTEGER NOT NULL REFERENCES accounts(account_id),
    amount_paise INTEGER NOT NULL CHECK (amount_paise > 0),
    status TEXT NOT NULL
        CHECK (status IN ('PENDING', 'COMPLETED', 'CANCELLED', 'FAILED')),
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    finalized_at TEXT,
    cancelled_at TEXT,
    CHECK (sender_account_id <> receiver_account_id)
);

CREATE TABLE IF NOT EXISTS ledger_entries (
    entry_id INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_id TEXT NOT NULL REFERENCES transactions(transaction_id),
    account_id INTEGER NOT NULL REFERENCES accounts(account_id),
    entry_type TEXT NOT NULL CHECK (entry_type IN ('DEBIT', 'CREDIT')),
    amount_paise INTEGER NOT NULL CHECK (amount_paise > 0),
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_logs (
    audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
    actor_account_id INTEGER REFERENCES accounts(account_id),
    action TEXT NOT NULL,
    entity_id TEXT,
    details TEXT,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_transactions_status_expiry
    ON transactions(status, expires_at);
CREATE INDEX IF NOT EXISTS idx_transactions_sender
    ON transactions(sender_account_id, created_at);
CREATE INDEX IF NOT EXISTS idx_transactions_receiver
    ON transactions(receiver_account_id, created_at);
CREATE INDEX IF NOT EXISTS idx_ledger_transaction
    ON ledger_entries(transaction_id);
CREATE INDEX IF NOT EXISTS idx_audit_actor_time
    ON audit_logs(actor_account_id, created_at);
