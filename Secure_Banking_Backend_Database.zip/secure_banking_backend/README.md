# Secure Banking Management System — Backend and Database

A Python + Flask + SQLite **academic prototype** implementing account registration/login, simulated transfers, transaction history, and a 30-second cancellation window.

> This is a learning project only. It does not connect to real banks, UPI, NEFT, RTGS, cards, or payment gateways. Do not use real financial or personal data.

## Features

- SQLite database with `accounts`, `transactions`, `ledger_entries`, and `audit_logs`.
- Password hashes using Werkzeug's maintained password-hashing helpers (no plain-text passwords).
- Amounts stored as integer paise to avoid floating-point money arithmetic.
- Pending transfer reserves funds for 30 seconds.
- Sender can cancel while the undo window is open.
- Expired transfers are finalized on demand when account/transaction data is accessed.
- Finalization uses a database transaction and a conditional status transition to avoid duplicate processing.
- Transfer history and a basic integrity-check endpoint.
- Parameterized SQL statements and foreign-key constraints.

## Requirements

- Python 3.10+
- pip

## Setup

### Windows (PowerShell / Command Prompt)

```bash
cd secure_banking_backend
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
py app.py
```

### macOS / Linux

```bash
cd secure_banking_backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000/`. On first run, `banking.db` is created automatically.

For deployment, set a stable secret key in the environment rather than relying on the development default:

```bash
# PowerShell
$env:BANK_SECRET_KEY = "replace-with-a-long-random-secret"
py app.py
```

Do not expose Flask's development server directly to the public internet. Use a production WSGI server, HTTPS, CSRF protections for cookie-authenticated browser requests, rate limiting, and a security review before any deployment.

## API quick start

Use Postman or curl. Requests with JSON should send `Content-Type: application/json`. Keep the same cookie/session between requests.

### 1. Register

`POST /api/register`

```json
{
  "full_name": "Demo User",
  "username": "demo_user",
  "password": "ChangeThisPassword123"
}
```

Registration creates a zero-balance account. The response includes the generated `account_number`; use that as the recipient identifier in another account's transfer request.

### 2. Login

`POST /api/login`

```json
{
  "username": "demo_user",
  "password": "ChangeThisPassword123"
}
```

### 3. View current account

`GET /api/me`

### 4. Create a transfer

`POST /api/transfers`

```json
{
  "receiver_account_number": "ACCOUNT_NUMBER_FROM_RECIPIENT",
  "amount": "25.50"
}
```

A successful response is `PENDING`. The sender's available balance is reduced because the amount is reserved, but the posted balance does not change until finalization.

### 5. Cancel during the undo window

`POST /api/transfers/TRANSACTION_UUID/cancel`

Only the sender can cancel, and only before the server-side expiry timestamp.

### 6. View history

`GET /api/transactions`

### 7. Run a basic integrity check

`GET /api/integrity-check`

### 8. Logout

`POST /api/logout`

## Database overview

- `accounts`: account identity, password hash, posted balance, reserved balance, and status.
- `transactions`: sender, receiver, amount, status, creation time, expiry time, and finalization/cancellation time.
- `ledger_entries`: append-only debit/credit rows for completed transfers.
- `audit_logs`: key events such as account creation, login, transfer request, completion, and cancellation.

Amounts are stored as paise: ₹25.50 = `2550`.

## Important implementation note

Expired transfers are processed on demand when a user checks their account/history or requests a transfer. For a continuously running demonstration, a background scheduler can be added. On a real service, the expiry worker, transaction locking, monitoring, reconciliation, backups, and security controls would need production-grade design.

## Suggested next steps

1. Build a frontend and call these endpoints.
2. Add unit tests using a temporary SQLite database.
3. Add a dedicated expiry worker and reconciliation report.
4. For multi-user deployment, consider PostgreSQL and a production deployment/security review.
