import unittest
from app import to_paise

class AmountTests(unittest.TestCase):
    def test_valid_amount(self):
        self.assertEqual(to_paise("25.50"), 2550)
        self.assertEqual(to_paise("1"), 100)

    def test_reject_non_positive(self):
        for value in ("0", "-1", "0.00"):
            with self.assertRaises(ValueError):
                to_paise(value)

    def test_reject_more_than_two_decimals(self):
        with self.assertRaises(ValueError):
            to_paise("1.234")

if __name__ == "__main__":
    unittest.main()
